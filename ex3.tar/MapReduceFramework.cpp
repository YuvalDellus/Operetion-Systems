//
// Created by yuliavar on 5/4/19.
//
#include "MapReduceFramework.h"
#include <pthread.h>
#include <stdio.h>
#include <iostream>
#include <array>
#include <atomic>
#include <cstdio> // ??
#include <algorithm>
#include <semaphore.h>
#include "Barrier.h"
#include <string>


typedef struct JobContext{

    typedef std::vector<IntermediatePair> IntermediateVec;
    bool is_done;
    int threads_amount;
    const InputVec *inputv;
    OutputVec* outputv;
    pthread_t *threads;
    std::vector<IntermediateVec> *ready_shuffled_vectors;
    std::vector<IntermediateVec*> *sortedInterVectors;


    const MapReduceClient *clientv;
    JobState* state;

    sem_t *ready_shuffled_sem;

    std::atomic<int>* atomic_counter; // for the first phase, helps to distribute the input vector
    std::atomic<bool>* to_shuffle;
    std::atomic<bool>* atomic_wait;


    pthread_mutex_t* client_mutex;
    pthread_mutex_t* output_vector_mutex;
    pthread_mutex_t* sort_mutex;
    pthread_mutex_t* shuffle_mutex;


    ~JobContext()
    {
        pthread_mutex_destroy(client_mutex);
        pthread_mutex_destroy(output_vector_mutex);
        pthread_mutex_destroy(sort_mutex);
        pthread_mutex_destroy(shuffle_mutex);

        sem_destroy(ready_shuffled_sem);


        for(int i = 0; i < (int)ready_shuffled_vectors->size();i++)
        {
            if(!ready_shuffled_vectors[i].empty())
            free(&ready_shuffled_vectors[i]);
        }
//        int i=0;
//        while (!sortedInterVectors->empty())
//        {
//            delete(&sortedInterVectors[i]);
//            i++;
//        }
        delete(client_mutex);
        delete(output_vector_mutex);
        delete(sort_mutex);
        delete(shuffle_mutex);
        delete(sortedInterVectors);
        delete(ready_shuffled_vectors);
        delete(atomic_counter);
        delete(atomic_wait);
        delete(to_shuffle);
        delete(state);
        delete(ready_shuffled_sem);
        delete[] threads;
        delete(bar);
    }

    Barrier *bar;


}JobContext;

InputVec input;
OutputVec outputVec;

void terminate_with_error(const std::string &message,JobContext *job_context)
{
    std::cerr<<message;
    delete(job_context);
    exit(1);
}

void mapSortStage(JobContext *job_contex) {

    job_contex->state->stage = MAP_STAGE;
    const InputVec input_vector = *job_contex->inputv;
    auto interForThread = new IntermediateVec();
    int old_pair = ((*job_contex->atomic_counter))++;
    while (old_pair < (int)job_contex->inputv->size()) {

        auto sing_pair = input_vector[old_pair];
        job_contex->clientv->map(sing_pair.first, sing_pair.second, interForThread);

        old_pair = ((*job_contex->atomic_counter))++;
    }

    std::sort(interForThread->begin(), interForThread->end(),
              [](const IntermediatePair &p1, const IntermediatePair &p2) { return *p1.first < *p2.first; });
    job_contex->state->percentage = ((float)*job_contex->atomic_counter/(float)input_vector.size()*100);

    if (pthread_mutex_lock(job_contex->sort_mutex) != 0) {
        std::cerr << "sort mutex error\n";
        exit(1);
    }

    if(!interForThread->empty())
    {
        job_contex->sortedInterVectors->push_back(interForThread);

    } else
    {
        delete(interForThread);
    }

    if (pthread_mutex_unlock(job_contex->sort_mutex) != 0) {
        std::cerr << "sort mutex error\n";
        exit(1);
    }

}

void emit2(K2 *key, V2 *value, void *context) {


    auto interPair = new IntermediatePair(key, value);

    ((IntermediateVec *) context)->push_back(*interPair);
    delete(interPair);

}

void reduceStage(JobContext *job_contex) {


    job_contex->state->stage = REDUCE_STAGE;
    job_contex->state->percentage = 0;

    while (!job_contex->ready_shuffled_vectors->empty())
    {

        if (sem_wait(job_contex->ready_shuffled_sem) != 0)
        {
            std::cout << "semaphore decrement error\n";
            exit(1);
        }

        if(job_contex->ready_shuffled_vectors->empty()){
            break;
        }

        if (pthread_mutex_lock(job_contex->shuffle_mutex) !=0)
        {
           terminate_with_error("client mutex error", job_contex);
        }
        auto first_shuffled = new IntermediateVec(job_contex->ready_shuffled_vectors->front());
        job_contex->ready_shuffled_vectors->erase(job_contex->ready_shuffled_vectors->begin());
        if (pthread_mutex_unlock(job_contex->shuffle_mutex) != 0)
        {
            std::cerr<<"Reduce error\n";
            exit(1);
        }
        job_contex->clientv->reduce(first_shuffled, job_contex);
        delete(first_shuffled);
        job_contex->state->percentage = ((job_contex->outputv->size() / job_contex->inputv->size()) *100);
        if (pthread_mutex_unlock(job_contex->client_mutex) != 0)
        {
            std::cerr<<"Reduce error\n";
            exit(1);
        }
    }
}

void emit3(K3 *key, V3 *value, void *context) {

    auto job_contex = (JobContext *) context;

    auto output_pair = new OutputPair(key, value);
    if (pthread_mutex_lock(job_contex->output_vector_mutex) != 0)
    {
        std::cerr << "mapping mutex error";
        exit(1);
    }
    job_contex->outputv->push_back(*output_pair);//.push_back(output_pair);
    delete(output_pair);
    if (pthread_mutex_unlock(job_contex->output_vector_mutex) != 0)
    {
        std::cerr << "output mutex error";
        exit(1);
    }

}

bool isEqule(K2 &pair1, K2 &pair2) {
    return !(pair1 < pair2) && !(pair2 < pair1);
}

void shuffleStage(JobContext *job) {

    std::vector<IntermediateVec *> main_vec = *job->sortedInterVectors;
    K2 *currentKey;

    auto max_key = new IntermediatePair ( main_vec.front()->back());//

    while (!main_vec.empty()) {

        int index_on_main_vec = 0;
        int index_max = 0;

        auto current_v = new IntermediateVec();

        while (index_on_main_vec <(int) main_vec.size()) {
            if(main_vec[index_on_main_vec]->empty())
            {
            index_on_main_vec++;
            continue;
            }

            currentKey = main_vec[index_on_main_vec]->back().first;


            if (*(max_key->first)  < *(currentKey) ) {
                max_key->first = currentKey;

                index_max = index_on_main_vec;
            }

            index_on_main_vec++;
        }

        while (index_max < (int)main_vec.size()) // itterate on all vectors from the one with max key onward
        {
            while (isEqule(*(main_vec[index_max]->back().first), *(max_key->first))) // different keys in same vector
            {

                current_v->push_back(main_vec[index_max]->back());
                    main_vec[index_max]->pop_back();
                if (main_vec[index_max]->empty()) {
                    delete(main_vec[index_max]);
                    main_vec.erase(main_vec.begin() + index_max); // if vector is empty delete it
                    index_max--;
                    break;
                }
            }
            index_max++;
        }
        if(pthread_mutex_lock(job->shuffle_mutex)!=0){
            terminate_with_error("mutex error", job);
        }
        job->ready_shuffled_vectors->push_back(*current_v);
        delete(current_v);
        if(pthread_mutex_unlock(job->shuffle_mutex)!=0){
            terminate_with_error("mutex error", job);
        }
        if (sem_post(job->ready_shuffled_sem) != 0) {
            std::cout << ("Shuffle Sem error\n");
        }
        if(!main_vec.empty()) {
            *max_key = main_vec.front()->back();// move to next vector
        }
    }


    job->is_done = true;
    for(int i = 0; i < job->threads_amount; ++i){
        if (sem_post(job->ready_shuffled_sem) != 0) {
            std::cout << ("Shuffle Sem error\n");
        }
    }
    delete(max_key);
}

void *mapReduce(void *job) {

    auto job_contex = (JobContext *) job;

    mapSortStage(job_contex);
    job_contex->bar->barrier();

    if (*job_contex->to_shuffle) {
        *job_contex->to_shuffle = false;
        shuffleStage(job_contex);
    }
    reduceStage(job_contex);

    return (void *) nullptr;
}

JobHandle startMapReduceJob(const MapReduceClient &client,
                            const InputVec &inputVec, OutputVec &outputVec,
                            int multiThreadLevel) {

    auto job = new JobContext;
    job->inputv = &inputVec;
    job->outputv = &outputVec;
    job->clientv = &client;
    job->threads_amount = std::min<int>(multiThreadLevel, (int) inputVec.size());

    //----------------------------all the news------------------------------
    job->state = new JobState();
    job->threads = new pthread_t[job->threads_amount];
    job->bar = new Barrier(job->threads_amount); // Barrier after sorting stage
    job->ready_shuffled_sem = new sem_t();
    job->ready_shuffled_vectors = new std::vector<IntermediateVec>;
    job->sortedInterVectors = new std::vector<IntermediateVec*>;

    //-----new for mutexes----

    job->client_mutex = new pthread_mutex_t();
    job->output_vector_mutex = new pthread_mutex_t();
    job->sort_mutex = new pthread_mutex_t();
    job->shuffle_mutex = new pthread_mutex_t();

    //-----new for atomics----

    job->atomic_counter = new std::atomic<int>{0};
    job->to_shuffle =  new std::atomic<bool>{true};
    job->atomic_wait = new std::atomic<bool>{true};



    if (sem_init(job->ready_shuffled_sem, 0, 0) != 0)
    {
        terminate_with_error("error Semaphore\n",job);
    }

    job->state->percentage = 0;
    job->state->stage = UNDEFINED_STAGE;

    for (int i = 0; i < job->threads_amount; i++) {
        if (pthread_create(&job->threads[i], NULL, mapReduce, job)) {
            terminate_with_error("error creating threads\n",job);
        }
    }
    return (void *) job;
}

void getJobState(JobHandle job, JobState *state) {
    auto given_job = (JobContext *) job;
    state->stage = given_job->state->stage;
    state->percentage = given_job->state->percentage;

}

void closeJobHandle(JobHandle job) {
    if (!job) return;

    if(*((JobContext*)job)->atomic_wait==true)
    {
        *((JobContext*)job)->atomic_wait = false;
        waitForJob(job);
    };
    delete (JobContext*)job;
}

void waitForJob(JobHandle job) {

    auto job_context = (JobContext *) job;
    *((JobContext*)job)->atomic_wait = false;


    for (int t = 0; t < job_context->threads_amount; t++) {

        if (pthread_join(job_context->threads[t], nullptr) != 0) {
            printf("ERROR \n");
            exit(-1);
        }
    }
}

