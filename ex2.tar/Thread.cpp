#include "Thread.h"
#include "uthreads.h" // Constructor

#define READY 1
#define  RUNNING 0

char stack[STACK_SIZE];
typedef unsigned long address_t;

/**
 * default constructor for the main Thread, used only for the uthread init process.
 */
Thread::Thread() {
    quantum = 1;
    tid = 0;
    statusID = RUNNING;
    sleeping = false;
}
/**
 *  The constructor of the Thread class.
 *  creates a new Thread with minimal tid and saves it's enviroment
 * @param tid The minimal available number will be used ti identify the Thread.
 * @param entring_point The function that that will be the Thread mission.
 */
Thread::Thread(int tid, void (*entring_point)()) : tid(tid){

    address_t sp, pc;
    quantum = 0;
    stack = new char[STACK_SIZE];
    statusID = READY;
    sleeping = false;
    sp = (address_t) stack + STACK_SIZE - sizeof(address_t);  // why - sizeof address_t?should we alloc the stack?
    pc = (address_t) entring_point;
    auto translatedSp = translate_address(sp);
    auto translatedPc = translate_address(pc);
    sigsetjmp(env, 1);
    (env->__jmpbuf)[JB_SP] = translatedSp;
    (env->__jmpbuf)[JB_PC] = translatedPc;
    sigemptyset(&env->__saved_mask);
}

/**
 * Translte the address for the system.
 */
address_t Thread::translate_address(address_t addr) {
    address_t ret;
    asm volatile("xor    %%fs:0x30,%0\n"
                 "rol    $0x11,%0\n"
    : "=g" (ret)
    : "0" (addr));
    return ret;
}


// --------------------------------------  Getters --------------------------------------

/**
 * @return The Id of the Thread.
 */
int Thread::getTid() {
    return tid;
}

/**
 * @return The quantum of the Thread, how many times The Thread has been called.
 */
int Thread::getQuantum() {
    return quantum;
}

/**
 * @return The status of the Thread, can be Ready, Running or Blocked.
 */
int Thread::getStatusID() {
    return statusID;
}

/**
 * @return The sleeping status of The Thread. True iff the Thread is sleeping.
 */
bool Thread::is_sleeping() const {
    return sleeping;
}

// --------------------------------------  Setters  --------------------------------------

/**
 * Increases the quantum of the Thread.
 */
void Thread::incQuantum() {
    Thread::quantum++;
}

/**
 * Set The status of the Thread, can be Ready, Running or Blocked.
 * @param statusID The new status of the Thread.
 */
void Thread::setStatusID(int statusID) {
    Thread::statusID = statusID;
}


/**
 * Set the sleeping status of The Thread. True iff the Thread is sleeping.
 * @param to_sleep The new sleeping status.
 */
void Thread::set_sleeping(bool to_sleep) {
    Thread::sleeping = to_sleep;
}


/**
 * The Distractor of the Thread class.
 */
Thread::~Thread() {
    delete (stack);

}

