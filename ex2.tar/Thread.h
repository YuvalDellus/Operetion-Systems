#include <setjmp.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <sys/time.h>

#ifndef OS_THREAD_H

#define OS_THREAD_H

#define STACK_SIZE 4096
#define MAX_THREAD_NUM 100

class Thread {

#define JB_SP 6
#define JB_PC 7

    int tid;
    int quantum;
    int statusID;
    char* stack;
    bool sleeping;

public:

    typedef unsigned long address_t;
    sigjmp_buf  env;

public:

    /**
     * default constructor for the main Thread, used only for the uthread init process.
     */
    Thread();

    /**
     *  The constructor of the Thread class.
     *  creates a new Thread with minimal tid and saves it's enviroment
     * @param tid The minimal available number will be used ti identify the Thread.
     * @param entring_point The function that that will be the Thread mission.
     */
    Thread(int tid, void (*entring_point)(void));

    /**
     * Translte the address for the system.
     */
    address_t translate_address(address_t addr);



    void set_sleeping(bool to_sleep);

    int getTid();

    int getQuantum();

    int getStatusID();

    void incQuantum();

    void setStatusID(int statusID);

    virtual ~Thread();
    bool is_sleeping() const;

};


#endif //OS_THREAD_H
