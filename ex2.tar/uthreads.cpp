//
// Created by yuliavar on 3/31/19.
//
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include "uthreads.h"
#include "sleeping_threads_list.h"
#include "Thread.h"
#include <queue>
#include <algorithm>
#include <iostream>
#include <string>


#define OUT_OF_INDEX_TID_MSG "Thread library error: the thread id is invalid"
#define NO_THREAD_IN_SYSTEM_MSG "Thread library error: no such thread in the system"
#define MAIN_THREAD_ILLIGAL_MSG "Thread library error: Illeagel action on main thread"
#define NON_POSATIVE_QUANTUM_MSG "Thread library error: quantum can't be non positive"
#define TOO_MANY_THREADS_MSG "Thread library error: too many existing threads"
#define MASKING_ERROR_MSG "Masking error"
#define SIGACTION_ERROR "Sigaction error"
#define SIGSET_ERROR "Sigaddset error"
#define EMPTY_SLEEP_LIST "No sleeping threads"
#define TIMER_ERROR "Timer error"

#define MAIN_THREAD 0
#define GENERAL_ERROR 0
#define SYS_ERROR 1
#define FAIL (-1)
#define SUCCESS 0
#define NORMALIZER 1000000
#define MAX_THREAD_NUM 100 /* maximal number of threads */
#define STACK_SIZE 4096 /* stack size per thread (in bytes) */
#define RUNNING 0
#define READY 1
#define BLOCKED 2
#define TERMINATE 3
#define SLEEP 4

int main_quantum;
int last_tid = 0;

/* External interface */
Thread *all_threads[MAX_THREAD_NUM];
Thread *running_thread;
std::deque<Thread *> ready_threads;
std::deque<Thread *> blocked_threads;
SleepingThreadsList sleeping_threads;

sigset_t masking_set;
sigset_t sleep_masking_set;

struct itimerval vttimer;
struct itimerval real_timer;
struct sigaction sa{};
struct sigaction sa_wake{};


// Added functions

/**
 * deletes all existing threads
 */
void destroy_process() {
    for (Thread* thread : all_threads) {
        free(thread);
    }
}

/**
 * output an error message and executes the requested action
 * @param message
 * @param action if GENERAL return FAIL if SYS exit with 1
 * @return FAIL or exit
 */
int error_action(std::string message, int action) {

    std::cerr<<message<<std::endl;
    if (action == GENERAL_ERROR) {
        return FAIL;
    }
    destroy_process();
    exit(1);
}

/**
 * @return the smallest available id for a thread.
 * -1 if no more available id's
 */
int get_new_thread_num() {

    int i = 0;

    while (all_threads[i])
    {
        i++;
    }

    if (i > MAX_THREAD_NUM) {
        return error_action(TOO_MANY_THREADS_MSG, GENERAL_ERROR);
    }

    return i;
}
/**
 * starts a blocking for signals
 * @return -1 if failed, 1 if succeeded
 */
int create_mask() {

    if (sigprocmask(SIG_BLOCK, &masking_set, nullptr) == FAIL) {
        return error_action(MASKING_ERROR_MSG, SYS_ERROR);
    }
    return SUCCESS;

}

/**
 * adjusts thread to new status, pushes to queue if needed changes status
 * @param thread
 * @param newStaus
 * @return SUCCESS or FAIL
 */
void move_to_state(Thread *thread, int newStaus) {
    if (newStaus == READY) {
        ready_threads.push_back(thread);
    } else {
        blocked_threads.push_back(thread);
    }

    thread->setStatusID(newStaus);

}


/**
 * unblocks the masking
 * @return -1 if masking failed
 */
int release_mask() {

    if (sigprocmask(SIG_UNBLOCK, &masking_set, nullptr) == FAIL) {
        return error_action(MASKING_ERROR_MSG, SYS_ERROR);
    }
    return SUCCESS;

}


/**
 * removes a thread from the list of it current status
 * @param thread to remove from list
 * @return SUCCESS or FAIL
 */
int remove_from_state(Thread *thread) {
    int thread_status = thread->getStatusID();

    if (thread->is_sleeping())
    {
        sleeping_threads.delete_by_id(thread->getTid());
        return SUCCESS;
    }

    if (thread_status == READY) {
        ready_threads.erase(std::find(ready_threads.begin(), ready_threads.end(), thread));// need to put nlptr?
    }
    if(thread_status == BLOCKED) {
        blocked_threads.erase(std::find(blocked_threads.begin(), blocked_threads.end(), thread));
    }
    return SUCCESS;
}

/**
 * Handler for SIGALRM, when called wakes up the next Thread in the sleeping list. called only when a wakeup
 * timer of the first Thread in the list ends.
 */
void wake(int a)
{
    create_mask();

    if (sleeping_threads.isEmpty())
    {
        release_mask();
        return;
    }

    int tid = sleeping_threads.peek()->id;
    timeval top_time = sleeping_threads.peek()->awaken_tv;


    Thread* thread_to_wake = all_threads[tid];
    thread_to_wake->set_sleeping(false);
    move_to_state(thread_to_wake, thread_to_wake->getStatusID());
    sleeping_threads.pop();



    // Checks if few Threads ends at the same time.
    while (!sleeping_threads.isEmpty() and timercmp(&top_time, &sleeping_threads.peek()->awaken_tv, <=))
    {
        tid = sleeping_threads.peek()->id;
        top_time = sleeping_threads.peek()->awaken_tv;


        thread_to_wake = all_threads[tid];
        thread_to_wake->set_sleeping(false);
        move_to_state(thread_to_wake, thread_to_wake->getStatusID());
        sleeping_threads.pop();
    }


    if (!sleeping_threads.isEmpty()) // Updatets the wake up time of the next Thread and set the timer accordingly
    {

        timeval now, next_wakeup;
        gettimeofday(&now, nullptr);
        timersub(&sleeping_threads.peek()->awaken_tv, &now, &next_wakeup);
        real_timer.it_value.tv_sec = next_wakeup.tv_sec;
        real_timer.it_value.tv_usec = next_wakeup.tv_usec;
        if (setitimer(ITIMER_REAL, &real_timer, nullptr) < 0) {
            release_mask();
            error_action(TIMER_ERROR, SYS_ERROR);
        }

        release_mask();
    }
}


/**
 * according to action decides what to do with the thread
 * @param action
 * @param thread previously running thread
 */
void old_thread_handle(int action, Thread *thread) {
    switch (action) {
        case BLOCKED:
            move_to_state(thread, BLOCKED);
            return;
        case TERMINATE:
            all_threads[thread->getTid()] = nullptr;
            free(thread);
            return;
        case SLEEP:
            thread->set_sleeping(true);
            thread->setStatusID(READY);
            return ;
        default:
            move_to_state(thread, READY);
    }

}

/**
 * reset the timer
 * @return SUCCESS or FAIL
 */
int reset_vttimer() {
    if (setitimer(ITIMER_VIRTUAL, &vttimer, NULL))
    {
        return error_action("setitimer error.", SYS_ERROR);
    }
    return SUCCESS;
}

/**
 * increases quantum of running thread and the main_quantum
 */
void increase_both_quantums() {
    running_thread->incQuantum();
    main_quantum++;
}

/**
 *
 * @param usecs_to_sleep
 * @return real time to wake up
 */
timeval calc_wake_up_timeval(int usecs_to_sleep) {

    timeval now, time_to_sleep, wake_up_timeval;
    gettimeofday(&now, nullptr);
    time_to_sleep.tv_sec = usecs_to_sleep / NORMALIZER;
    time_to_sleep.tv_usec = usecs_to_sleep % NORMALIZER;
    timeradd(&now, &time_to_sleep, &wake_up_timeval);
    return wake_up_timeval;
}

/**
 * handler for virtual timer
 * @param action_indecator indicates what to do with the running thread that is released.
 */
void switchThreads(int action_indecator) {

    if(create_mask()==FAIL)
    {
        return;
    }

    if (ready_threads.empty()) {
        increase_both_quantums();
        release_mask();
        return;
    }

    int ret_val = sigsetjmp(running_thread->env, 1);

    if (ret_val == 1) {
        release_mask();
        return;
    }

    old_thread_handle(action_indecator, running_thread);
    running_thread = ready_threads.front();
    ready_threads.pop_front();
    running_thread->setStatusID(RUNNING);

    increase_both_quantums();

    reset_vttimer();

    if(release_mask()==FAIL)
    {
        return;
    }

    siglongjmp(running_thread->env, 1);
}

//implemented from API

/**
 * This function initializes the thread library.
 * You may assume that this function is called before any other thread library
 * function, and that it is called exactly once. The input to the function is
 * the length of a quantum in micro-seconds. It is an error to call this
 * function with non-positive quantum_usecs.
 * @param quantum_usecs
 * @return On success, return 0. On failure, return -1
 */
int uthread_init(int quantum_usecs) {
    main_quantum = 1;
    if (quantum_usecs <= 0)
    {
        return error_action(NON_POSATIVE_QUANTUM_MSG, GENERAL_ERROR);
    }

    sa.sa_handler = &switchThreads;

    if (sigaction(SIGVTALRM, &sa, nullptr) < 0) {
        return error_action(SIGACTION_ERROR, SYS_ERROR);
    }

    if (sigaddset(&masking_set, SIGVTALRM) < 0) {
        return error_action(SIGSET_ERROR, SYS_ERROR);
    }

    sa_wake.sa_handler = &wake;

    if (sigaction(SIGALRM, &sa_wake, nullptr) < 0) {
        return error_action(SIGACTION_ERROR, SYS_ERROR);
    }

    if (sigaddset(&sleep_masking_set, SIGALRM) < 0) {
        return error_action(SIGSET_ERROR, SYS_ERROR);
    }

    vttimer.it_value.tv_sec = quantum_usecs / NORMALIZER;        // first time interval, seconds part
    vttimer.it_value.tv_usec = quantum_usecs % NORMALIZER;        // first time interval, microseconds part

    vttimer.it_interval.tv_sec = quantum_usecs / NORMALIZER;    // following time intervals, seconds part
    vttimer.it_interval.tv_usec = quantum_usecs % NORMALIZER;    // following time intervals, microseconds part

    if (reset_vttimer() == FAIL) {
        return FAIL;
    }

    running_thread = new Thread(); //main thread
    all_threads[MAIN_THREAD] = running_thread;

    last_tid++;

    return SUCCESS;
}

/**
 * This function creates a new thread, whose entry point is the
 * function f with the signature void f(void). The thread is added to the end
 * of the READY threads list. The uthread_spawn function should fail if it
 * would cause the number of concurrent threads to exceed the limit
 * (MAX_THREAD_NUM). Each thread should be allocated with a stack of size
 * STACK_SIZE bytes.
 * @param f
 * @return On success, return the ID of the created thread.
 * On failure, return -1
 */
int uthread_spawn(void (*f)(void)) {

    if (create_mask() == FAIL) {
        return FAIL;
    }

    int new_tid = get_new_thread_num();

    if(new_tid == FAIL)
    {
        release_mask();
        return FAIL;
    }

    Thread *newThread = new Thread(new_tid, f);
    ready_threads.push_back(newThread);
    all_threads[new_tid] = newThread;

    if (release_mask() == FAIL) {
        return FAIL;
    }

    return new_tid;
}

/**
 * This function terminates the thread with ID tid and deletes
 * it from all relevant control structures. All t he resources allocated by
 * the library for this thread should be released. If no thread with ID tid
 * exists it is considered an error. Terminating the main thread
 * (tid == 0) will result in the termination of the entire process using
 * exit(0) [after releasing the assigned library memory].
 * @param tid
 * @return The function returns 0 if the thread was successfully
 * terminated and -1 otherwise. If a thread terminates itself or the main
 * thread is terminated, the function does not return.
 */
int uthread_terminate(int tid) {
    if(create_mask() == FAIL)
    {
        return FAIL;
    }
    if (tid > MAX_THREAD_NUM or tid < 0) {
        release_mask();
        return error_action(OUT_OF_INDEX_TID_MSG, GENERAL_ERROR);
    }
    if (tid == MAIN_THREAD) {
        release_mask();
        destroy_process();
        exit(1);
    }

    Thread *to_delete = all_threads[tid];

    if (!to_delete)
    {
        release_mask();
        return error_action(NO_THREAD_IN_SYSTEM_MSG, GENERAL_ERROR);
    }

    if (to_delete->getStatusID() == RUNNING) {

        release_mask();
        switchThreads(TERMINATE);
    }

    if (remove_from_state(to_delete) == FAIL) {
        release_mask();
        return FAIL;
    }

    all_threads[tid] = nullptr;
    free(to_delete);
    return release_mask();

}

/**
 * This function blocks the thread with ID tid. The thread may
 * be resumed later using uthread_resume. If no thread with ID tid exists it
 * is considered as an error. In addition, it is an error to try blocking the
 * main thread (tid == 0). If a thread blocks itself, a scheduling decision
 * should be made. Blocking a thread in BLOCKED state has no
 * effect and is not considered an error.
 * @param tid
 * @return On success, return 0. On failure, return -1.
 */
int uthread_block(int tid) {

    create_mask();
    if (tid > MAX_THREAD_NUM or tid < 0) {
        release_mask();
        return error_action(OUT_OF_INDEX_TID_MSG, GENERAL_ERROR);
    }

    if (tid == MAIN_THREAD) {
        release_mask();
        return error_action(MAIN_THREAD_ILLIGAL_MSG, GENERAL_ERROR);
    }

    Thread *to_block = all_threads[tid];

    if (!to_block)//check
    {
        release_mask();
        return error_action(NO_THREAD_IN_SYSTEM_MSG, GENERAL_ERROR);
    }

    if (to_block->getStatusID() == BLOCKED) // if already blocked
    {
        release_mask();
        return SUCCESS;
    }

    if (to_block->getStatusID() == RUNNING) {
        release_mask();
        switchThreads(BLOCKED);
        return SUCCESS;
    }

    if (to_block->is_sleeping()) {
        to_block->setStatusID(BLOCKED);

        release_mask();

        return SUCCESS;
    }


    if (remove_from_state(to_block) == FAIL )
    {

        release_mask();
        return FAIL;
    }

    move_to_state(to_block, BLOCKED);

    return release_mask();


}

/**
 * This function resumes a blocked thread with ID tid and moves
 * it to the READY state if it's not synced. Resuming a thread in a RUNNING or READY state
 * has no effect and is not considered as an error. If no thread with
 * ID tid exists it is considered an error.
 * @param tid
 * @return On success, return 0. On failure, return -1.
 */
int uthread_resume(int tid) {
    if (create_mask()==FAIL)
    {
        return FAIL;
    }
    if (tid > MAX_THREAD_NUM or tid < 0) {
        release_mask();
        return error_action(OUT_OF_INDEX_TID_MSG, GENERAL_ERROR);
    }

    Thread *to_resume = all_threads[tid];

    if (!to_resume)//if thread exists
    {
        release_mask();
        return error_action(NO_THREAD_IN_SYSTEM_MSG, GENERAL_ERROR);
    }

    if (to_resume->getStatusID() != BLOCKED) {
        release_mask();
        return SUCCESS;
    }

    if (to_resume->is_sleeping())
    {
        to_resume->setStatusID(READY);
        release_mask();
        return SUCCESS;
    }

    if (remove_from_state(to_resume) == FAIL )
    {
        release_mask();
        return FAIL;
    }
    move_to_state(to_resume, READY);
    return release_mask();

}


/**
 * This function returns the thread ID of the calling thread.
 * @return  The ID of the calling thread.
 */
int uthread_get_tid() {
    if(create_mask()==FAIL)
    {
        return FAIL;
    }
    int tid = running_thread->getTid();
    if(release_mask()==FAIL)
    {
        return FAIL;
    }
    return tid;
}

/**
 * his function returns the total number of quantums since
 * the library was initialized, including the current quantum.
 * Right after the call to uthread_init, the value should be 1.
 * Each time a new quantum starts, regardless of the reason, this number
 * should be increased by 1.
 * @return  The total number of quantums
 */
int uthread_get_total_quantums() {
    return main_quantum;
}

/**
 * This function returns the number of quantums the thread with
 * ID tid was in RUNNING state. On the first time a thread runs, the function
 * should return 1. Every additional quantum that the thread starts should
 * increase this value by 1 (so if the thread with ID tid is in RUNNING state
 * when this function is called, include also the current quantum). If no
 * thread with ID tid exists it is considered an error.
 * @param tid
 * @return On success, return the number of quantums of the thread with ID tid.
 * 			     On failure, return -1.
 */
int uthread_get_quantums(int tid) {
    if (tid > MAX_THREAD_NUM or tid < 0) {
        return error_action(OUT_OF_INDEX_TID_MSG, GENERAL_ERROR);
    }

    Thread *curr_thread = all_threads[tid];

    if (!curr_thread)
    {
        return error_action(NO_THREAD_IN_SYSTEM_MSG, GENERAL_ERROR);
    }

    return curr_thread->getQuantum();
}

/**
 * This function blocks the RUNNING thread for usecs micro-seconds in real time (not virtual
 * time on the cpu). It is considered an error if the main thread (tid==0) calls this function. Immediately after
 * the RUNNING thread transitions to the BLOCKED state a scheduling decision should be made.
 * After the sleeping time is over, the thread should go back to the end of the READY threads list.
 * @param usec
 * @return On success, return 0. On failure, return -1
 */
int uthread_sleep(unsigned int usec) {

    if(create_mask())
    {
        return error_action(MASKING_ERROR_MSG,SYS_ERROR);
    }
    int to_sleep_tid = running_thread->getTid();
    if(usec == 0)
    {
        if(release_mask()==FAIL)
        { return FAIL;}
        switchThreads(READY);
        return SUCCESS;
    }

    if (usec < 0) {
        release_mask();
        return error_action(NON_POSATIVE_QUANTUM_MSG, GENERAL_ERROR);
    }

    if (to_sleep_tid == MAIN_THREAD) {
        if(release_mask()==FAIL)
            return FAIL;
        return error_action(MAIN_THREAD_ILLIGAL_MSG, GENERAL_ERROR);
    }

    timeval wake_time = calc_wake_up_timeval(usec);

    if (sleeping_threads.isEmpty())
    {
        real_timer.it_value.tv_sec = usec / 1000000;
        real_timer.it_value.tv_usec = usec % 1000000;
        if (setitimer(ITIMER_REAL, &real_timer, nullptr) < 0)
        {
            return error_action(EMPTY_SLEEP_LIST,SYS_ERROR);
        }
    }

    if (!sleeping_threads.isEmpty()) {
        timeval top = sleeping_threads.peek()->awaken_tv;

        if (timercmp(&wake_time, &top, <=)) {
            real_timer.it_value.tv_sec = usec / 1000000;
            real_timer.it_value.tv_usec = usec % 1000000;
            if (setitimer(ITIMER_REAL, &real_timer, nullptr) < 0)
            {
                return error_action(TIMER_ERROR,SYS_ERROR);
            }
        }
    }

    sleeping_threads.add(to_sleep_tid, wake_time);
    switchThreads(SLEEP);

    return release_mask();

}






