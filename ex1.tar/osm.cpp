#include <iostream>
# include <time.h>
# include <sys/time.h>
#include "osm.h"

struct timeval start, end;


double osm_operation_time(unsigned int iterations)
{  /*does basic math operation
 * Returns 0 uppon success and -1 on failure
 */

    unsigned int i = 0;
    double time;
    iterations = iterations <= 0 ? (unsigned)10000: iterations;
    gettimeofday(&start, nullptr);
    int a = 0;

    for(;i <= iterations;i += 10)
        {
            a = 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1 + 1;
        }

    gettimeofday(&end, nullptr);

    a++; // just to use it cause the Warning

    time = (end.tv_usec-start.tv_usec)*1000/(float)iterations;
    return 0;
}

void do_nothing()
/*does nothing*/
{};


double osm_function_time(unsigned int iterations)
{
    /*calls a function "iteration" times
     * returns time in nano-seconds upon success,
    and -1 upon failure.*/
    unsigned int i = 0;
    iterations = iterations <= 0 ? (unsigned)10000: iterations;
    gettimeofday(&start, nullptr);

    for(;i <= iterations;i += 10)
    {
        do_nothing();
        do_nothing();
        do_nothing();
        do_nothing();
        do_nothing();
        do_nothing();
        do_nothing();
        do_nothing();
        do_nothing();
        do_nothing();
    }

    gettimeofday(&end, nullptr);

    return (end.tv_usec-start.tv_usec)*1000/(float)iterations;
}

double osm_syscall_time(unsigned int iterations)
{/*
 *  Time measurement function for an empty trap into the operating system.
   returns time in nano-seconds upon success,
   and -1 upon failure.

 */
    unsigned int i = 0;
    iterations = iterations<= 0 ? (unsigned)10000: iterations;
    gettimeofday(&start, nullptr);

    for(;i <= iterations;i += 10)
    {
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
        OSM_NULLSYSCALL;
    }

    gettimeofday(&end, nullptr);

    return (end.tv_usec-start.tv_usec)*1000/(float)iterations;
}
